
from datetime import datetime, time as tm
from typing import Optional, Dict, Any

def phase_active(now: Optional[datetime] = None, policy: Optional[Dict[str, Any]] = None) -> bool:
    """
    Simple day-phase gating: active between start_hour and end_hour (local time).
    policy: {"start_hour": 8, "end_hour": 22, "override": None|True|False}
    """
    policy = policy or {}
    if policy.get("override") is not None:
        return bool(policy["override"])
    start = int(policy.get("start_hour", 8))
    end = int(policy.get("end_hour", 22))
    now = now or datetime.now()
    return tm(start,0,0) <= now.time() <= tm(end,0,0)
