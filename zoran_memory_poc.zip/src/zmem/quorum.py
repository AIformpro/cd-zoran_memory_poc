
from collections import Counter
from typing import Dict, Any, List

# Decision enums
KEEP, MERGE, DROP = "keep", "merge", "drop"

def voters(key: str, value: str, meta: Dict[str, Any], recent_keys: List[str]) -> List[str]:
    votes = []
    # voter 1: duplicate recent key -> MERGE
    if recent_keys and key in recent_keys:
        votes.append(MERGE)
    else:
        votes.append(KEEP)
    # voter 2: very long value -> MERGE (truncate/summary expected by caller)
    if isinstance(value, str) and len(value) > 256:
        votes.append(MERGE)
    else:
        votes.append(KEEP)
    # voter 3: conflict marker in meta -> DROP
    if meta.get("conflict"):
        votes.append(DROP)
    else:
        votes.append(KEEP)
    return votes

def decide(votes: List[str]) -> str:
    c = Counter(votes)
    # majority; tie → KEEP
    best = c.most_common()
    if not best:
        return KEEP
    if len(best) > 1 and best[0][1] == best[1][1]:
        return KEEP
    return best[0][0]
