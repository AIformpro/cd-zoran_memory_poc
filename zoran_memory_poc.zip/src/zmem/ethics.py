
import re
from typing import Tuple, Dict, Any

EMAIL_RE = re.compile(r"([a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+)")
PHONE_RE = re.compile(r"(\+?\d[\d \-]{7,}\d)")

def minimize(key: str, value: str, meta: Dict[str, Any]) -> Tuple[str, str, Dict[str, Any]]:
    """
    Minimalist data minimization: redact emails/phones, trim very long values, attach info-only tags.
    """
    if isinstance(value, str):
        value = EMAIL_RE.sub("[email_redacted]", value)
        value = PHONE_RE.sub("[phone_redacted]", value)
        if len(value) > 512:
            value = value[:512] + "…"
    meta = dict(meta or {})
    meta.setdefault("minimized", True)
    meta.setdefault("len", len(value) if isinstance(value, str) else None)
    # lightweight TTL hint (consumer may enforce)
    meta.setdefault("ttl_hint_days", 365)
    return key, value, meta
