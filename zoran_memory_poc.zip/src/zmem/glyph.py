
import zlib, base64

MAGIC = "Z5::"

def pack(text: str) -> str:
    if not isinstance(text, (bytes, bytearray)):
        text = text.encode("utf-8")
    blob = zlib.compress(text, level=9)
    return MAGIC + base64.b64encode(blob).decode("ascii")

def unpack(blob: str) -> str:
    if not blob.startswith(MAGIC):
        return blob
    b = base64.b64decode(blob[len(MAGIC):].encode("ascii"))
    return zlib.decompress(b).decode("utf-8")
