
import time, copy, json, math, hashlib
from collections import deque, Counter
from typing import Dict, Any, Tuple, List

from .ethics import minimize
from .quorum import voters, decide, KEEP, MERGE, DROP
from .phase import phase_active

class DeltaMGuardError(RuntimeError):
    pass

class RingSnapshots:
    def __init__(self, capacity: int = 32):
        self.capacity = capacity
        self.buffer: List[Dict[str, Any]] = []
        self.ptr = 0

    def push(self, state: Dict[str, Any]):
        snap = copy.deepcopy(state)
        if len(self.buffer) < self.capacity:
            self.buffer.append(snap)
        else:
            self.buffer[self.ptr] = snap
        self.ptr = (self.ptr + 1) % self.capacity

    def last(self) -> Dict[str, Any] | None:
        if not self.buffer:
            return None
        return copy.deepcopy(self.buffer[(self.ptr - 1) % len(self.buffer)])

class FractalMemory:
    def __init__(self, short_window: int = 64, stability_threshold: float = 0.7, phase_policy: Dict[str, Any] = None):
        self.short_term = deque(maxlen=short_window)  # list of (ts, key, value, meta)
        self.long_term: Dict[str, Dict[str, Any]] = {}  # aggregates per key
        self.latent: Dict[str, List[str]] = {}  # embedding-hash -> [keys]
        self.parasitic_web: List[str] = []  # exportable fragments
        self.snapshots = RingSnapshots(64)
        self.metrics = {
            "commits": 0, "rollbacks": 0,
            "stability_last": 1.0, "stability_avg": 1.0,
            "phase_blocks": 0, "merges": 0, "drops": 0
        }
        self._stability_history: List[float] = []
        self.stability_threshold = stability_threshold
        self.phase_policy = phase_policy or {"start_hour": 8, "end_hour": 22}

    # --- internal utilities ---
    @staticmethod
    def _embed_key(key: str, value: str) -> str:
        # lightweight "embedding" via hash of normalized text
        norm = (key + "::" + (value or ""))[:1024].lower().encode("utf-8")
        return hashlib.sha1(norm).hexdigest()[:16]

    def _state(self) -> Dict[str, Any]:
        return {
            "short_term": list(self.short_term),
            "long_term": copy.deepcopy(self.long_term),
            "latent": copy.deepcopy(self.latent),
            "parasitic_web": list(self.parasitic_web),
            "metrics": copy.deepcopy(self.metrics),
            "stability_threshold": self.stability_threshold,
            "phase_policy": copy.deepcopy(self.phase_policy)
        }

    def _load_state(self, state: Dict[str, Any]):
        self.short_term = deque(state["short_term"], maxlen=self.short_term.maxlen)
        self.long_term = copy.deepcopy(state["long_term"])
        self.latent = copy.deepcopy(state["latent"])
        self.parasitic_web = list(state["parasitic_web"])
        self.metrics = copy.deepcopy(state["metrics"])
        self.stability_threshold = state["stability_threshold"]
        self.phase_policy = copy.deepcopy(state["phase_policy"])

    @staticmethod
    def _stability_from_recent(keys: List[str]) -> float:
        if not keys:
            return 1.0
        c = Counter(keys)
        total = sum(c.values())
        probs = [v/total for v in c.values()]
        # normalized entropy
        H = -sum(p*math.log2(p) for p in probs)
        Hmax = math.log2(len(c)) if len(c) > 1 else 1.0
        Hn = H / Hmax if Hmax > 0 else 0.0
        stability = 1.0 - Hn
        return max(0.0, min(1.0, stability))

    # --- public API ---
    def commit(self, key: str, value: str, meta: Dict[str, Any] = None) -> Dict[str, Any]:
        """Commit a (key, value). Applies ethics, quorum, phase-gating, ΔM11.3 rollback if needed."""
        ts = time.time()
        if not phase_active(policy=self.phase_policy):
            self.metrics["phase_blocks"] += 1
            return {"status": "blocked_by_phase"}

        # snapshot before mutation
        self.snapshots.push(self._state())

        # ethics minimization
        key, value, meta = minimize(key, value, meta or {})

        # quorum decision
        recent_keys = [k for (_, k, _, _) in list(self.short_term)]
        decision = decide(voters(key, value, meta, recent_keys))
        if decision == "drop":
            self.metrics["drops"] += 1
            return {"status": "dropped_by_quorum"}
        if decision == "merge":
            self.metrics["merges"] += 1
            # simplistic merge: shorten value, increment count later
            if isinstance(value, str) and len(value) > 180:
                value = value[:180] + "…"

        self.short_term.append((ts, key, value, meta))

        # update long_term aggregates
        slot = self.long_term.setdefault(key, {"count": 0, "last": None, "samples": []})
        slot["count"] += 1
        slot["last"] = {"ts": ts, "value": value}
        if len(slot["samples"]) < 32:
            slot["samples"].append(value)

        # latent hash "embedding"
        h = self._embed_key(key, value)
        self.latent.setdefault(h, [])
        if key not in self.latent[h]:
            self.latent[h].append(key)

        # export minimal fragment for parasitic web (could be dumped to disk later)
        frag_value = value[:64] + "…" if isinstance(value, str) and len(value) > 64 else value
        frag = f"{int(ts)}|{key}|{frag_value}"
        if isinstance(frag, str):
            self.parasitic_web.append(frag)

        # stability check
        window = list(self.short_term)[-32:]
        keys = [k for (_, k, _, _) in window]
        stability = self._stability_from_recent(keys)
        self._stability_history.append(stability)
        self.metrics["stability_last"] = stability
        self.metrics["stability_avg"] = sum(self._stability_history)/len(self._stability_history)
        self.metrics["commits"] += 1

        if stability < self.stability_threshold:
            # rollback
            prev = self.snapshots.last()
            if prev is None:
                raise DeltaMGuardError("ΔM11.3 triggered but no snapshot available")
            self._load_state(prev)
            self.metrics["rollbacks"] += 1
            return {"status": "rolled_back", "stability": stability}

        return {"status": "ok", "stability": stability}

    def export_metrics(self) -> Dict[str, Any]:
        return copy.deepcopy(self.metrics)

    def to_json(self) -> str:
        return json.dumps(self._state(), ensure_ascii=False, indent=2)

    def dump_fragments(self, path: str):
        with open(path, "w", encoding="utf-8") as f:
            for line in self.parasitic_web[-1024:]:
                f.write(line + "\n")
