
import os, json, time, random, string
from pathlib import Path
from zmem import FractalMemory

DATA = Path(__file__).resolve().parents[1] / "data"
DATA.mkdir(exist_ok=True, parents=True)

def rnd_key(prefix="topic"):
    return prefix + "_" + random.choice(["alpha","beta","gamma","delta","epsilon"])

def rnd_text(n=80):
    return "".join(random.choice(string.ascii_letters + " ") for _ in range(n))

def main():
    mem = FractalMemory(short_window=64, stability_threshold=0.70, phase_policy={"start_hour":0, "end_hour":23})  # keep active for demo

    # phase 1: coherent stream
    for i in range(12):
        res = mem.commit("project", f"update {i}: refining architecture and tests", {"source":"demo"})
        print(f"[phase1] commit {i}: {res}")
        time.sleep(0.005)

    # phase 2: mild diversity
    for i in range(8):
        k = rnd_key("project")
        res = mem.commit(k, f"note {i}: {rnd_text(60)}", {"source":"demo"})
        print(f"[phase2] {k}: {res}")
        time.sleep(0.003)

    # phase 3: chaos to trigger rollback
    for i in range(16):
        k = rnd_key("xnoise")
        res = mem.commit(k, f"noisy {i}: {rnd_text(200)}", {"source":"demo", "conflict": (i%7==0)})
        print(f"[phase3] {k}: {res}")
        if res.get("status") == "rolled_back":
            print("ΔM11.3 rollback occurred → stability restored.")
            break
        time.sleep(0.002)

    metrics = mem.export_metrics()
    (DATA / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    mem.dump_fragments(str(DATA / "fragments.zgs"))
    (DATA / "state.json").write_text(mem.to_json(), encoding="utf-8")
    print("Metrics:", json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
