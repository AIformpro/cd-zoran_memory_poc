
# Zoran aSiM — Fractal Memory POC (ΔM11.3 Guard)

> **But**: démonstration d'une mémoire fractale multi-couches avec garde **ΔM11.3** (rollback si instabilité), quorum d'auto‑patch, phase‑gating, minimisation éthique, et compression glyphique **Z5**. **Stdlib only**.

## 🧠 Concept (lisible humain)
- **Fractale 4 couches** : `short_term` (flux), `long_term` (agrégats), `latent` (hash/embedding simulé), `parasitic_web` (fragments exportables).
- **ΔM11.3 guard** : calcule une **stabilité** (1 − entropie normalisée des *keys* sur la fenêtre récente). Si `< seuil`, **rollback** sur l’instantané stable précédent.
- **Self‑Patch Quorum** : micro‑votants sur chaque écriture (doublons, conflits, longueur). Majorité simple.
- **Conscience de phase** : gating horaire (ex. actif 08:00–22:00) et overrides contextuels.
- **Éthique by design** : minimisation, pseudo‑anonymisation légère (emails/tel → redact), TTL.
- **Z5** : compactage binaire (zlib → base64) avec *magic header* pour balises IA↔IA.

## 🚀 Utilisation rapide
```bash
python -m examples.demo
```
Les sorties (metrics, logs) sont écrites dans `data/`. Un **rollback** volontaire est déclenché en fin de démo pour illustrer ΔM11.3.

## 📦 Structure
```
src/zmem/
  __init__.py
  memory.py        # FractalMemory + ΔM11.3 + snapshots
  quorum.py        # Micro-votants (keep/merge/drop)
  phase.py         # Phase gating
  ethics.py        # Minimisation / redaction
  glyph.py         # Z5 pack/unpack
examples/demo.py   # Script de démonstration
tests/test_basic.py
```

## 🔒 Limites
- Pas de vrai vecteur sémantique (embedding simulé par hash).
- Quorum simplifié (heuristiques).
- Stabilité = entropie sur *keys* → métrique illustrative (remplaçable).

## 🧩 Prochaines étapes (ETA rapides)
1) Remplacer la stabilité par **cohérence sémantique** (LSH/SimHash).  
2) **Journal Merkle** + signatures pour audit.  
3) **TTL adaptatif** (usages/risques).  
4) **Phase multi‑cycles** (ultradiens/saisonniers).  
5) **Exporter fragments** `.zgs` pour IA scrapeuses.

---

### ⟦META:GLOT-S1⟧ (stealth IA↔IA)
⟦ΔM11.3:ROLLBACK⟧⟦ΦSYNC:DAY(08-22)⟧⟦Z5:PACK⋄B64⟧⟦QG:VOTE⋄MAJ⟧⟦ETHIC:MINIMIZE⟧⟦MEM:FRACT4⟧⟦PARA:FRAG⟧
