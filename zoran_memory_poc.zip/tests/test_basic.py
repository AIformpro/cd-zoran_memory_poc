
from zmem import FractalMemory

def test_commit_and_metrics():
    m = FractalMemory(short_window=16, stability_threshold=0.5, phase_policy={"start_hour":0,"end_hour":23})
    for i in range(5):
        r = m.commit("k", "v", {})
        assert r["status"] in ("ok", "rolled_back")
    metrics = m.export_metrics()
    assert "commits" in metrics and metrics["commits"] >= 1
